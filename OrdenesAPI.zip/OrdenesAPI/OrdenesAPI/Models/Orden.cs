﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrdenesAPI.Models
{
    public class Orden
    {
        [Required(ErrorMessage = "El campo 'cliente' es obligatorio.")]
        public string cliente { get; set; }

        [Required(ErrorMessage = "El campo 'fecha' es obligatorio.")]
        public string fecha { get; set; }

        [Required(ErrorMessage = "La orden debe contener al menos un item.")]
        public List<Item> Items { get; set; }
    }

}