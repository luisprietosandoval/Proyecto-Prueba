﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrdenesAPI.Models
{
    public class Orden
    {
        [Required(ErrorMessage = "El campo 'cliente' es obligatorio.")]
        public string cliente { get; set; }

        [Required(ErrorMessage = "El campo 'fecha' es obligatorio.")]
        public string fecha { get; set; }

        [MinLength(1, ErrorMessage = "Debe haber al menos un item en la orden.")]
        public List<Item> items { get; set; }
    }

}