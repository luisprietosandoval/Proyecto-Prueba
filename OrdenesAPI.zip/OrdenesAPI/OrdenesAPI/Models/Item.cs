﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrdenesAPI.Models
{
    public class Item
    {
        public string sku { get; set; }
        public int cantidad { get; set; }
    }
}