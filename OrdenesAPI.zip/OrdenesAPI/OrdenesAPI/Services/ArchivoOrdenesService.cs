﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OrdenesAPI.Models;

namespace OrdenesAPI.Servicios
{
    public static class ArchivoOrdenesService
    {

        private static string rutaArchivo = @"C:\Users\SONY\eclipse-workspace\camel-integration\data\inbox\ordenes.json";
        //private static string rutaArchivoAPI = System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/ordenes.json");
        private static List<Orden> _ordenes = new List<Orden>
        {
            // new Orden { Id = 1, Cliente = "ACME Ltda", Fecha = "2025-08-10" },
            // new Orden { Id = 2, Cliente = "Globex Inc", Fecha = "2025-08-11" }
        };
        public static List<Orden> LeerOrdenesNew()
        {
                return _ordenes;
        }

        public static void GuardarOrdenes(Orden ordenes)
        {
            var contenido = JsonConvert.SerializeObject(ordenes, Formatting.Indented);

            File.WriteAllText(rutaArchivo, contenido);
            _ordenes.Add(ordenes);
            //File.WriteAllText(rutaArchivoAPI, contenido);
            

        }
    }
}