﻿using System;
using System.Collections.Generic;
using System.Linq;


using System.Collections.Generic;
using System.Web.Http;
using OrdenesAPI.Models;
using OrdenesAPI.Servicios;
using System.Web.Http.Cors;

namespace OrdenesAPI.Controllers
{
  
    [RoutePrefix("ordenes")]
    public class OrdenesController : ApiController
    {


        // GET /ordenes
        [HttpGet]
        [Route("ListaOrdenes")]
        public IHttpActionResult GetOrdenes()
        {
            var ordenes = ArchivoOrdenesService.LeerOrdenesNew();
            return Ok(ordenes);
        }

        // POST /ordenes
        [HttpPost]
        [Route("CrearOrden")]
        public IHttpActionResult CrearOrden([FromBody] Orden nuevaOrden)
        {
            if (nuevaOrden == null)
                return BadRequest("La orden no puede ser nula.");


            //_ordenes.Add(nuevaOrden);

            ArchivoOrdenesService.GuardarOrdenes(nuevaOrden);

            return Created($"/ordenes", nuevaOrden);
        }
    }
}