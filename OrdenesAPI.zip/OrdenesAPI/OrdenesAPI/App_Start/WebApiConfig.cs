﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Net.Http.Headers;
using System.Web.Http.Cors;

namespace OrdenesAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            /*
            var cors = new EnableCorsAttribute(
        origins: "*",
        headers: "*",
        methods: "GET,POST,PUT,DELETE,PATCH,OPTIONS"
    )
            {
                SupportsCredentials = false // ponlo en false si no usas cookies/autenticación por navegador
            };
            config.EnableCors(cors);
            */

            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // 👉 Eliminar soporte para XML
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            // 👉 Asegurarse de que JSON sea el formato por defecto
            config.Formatters.JsonFormatter.SupportedMediaTypes
                .Add(new MediaTypeHeaderValue("text/html"));
        }
    }
}
