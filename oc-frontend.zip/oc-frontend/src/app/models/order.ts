export interface Item {
  sku: string;           // nombre o código
  cantidad: number;      // >= 1
}

export interface Orden {
  id?: number;           // lo asigna el backend
  cliente: string;       // 2-100 chars
  fecha: string;         // "yyyy-MM-dd"
  items: Item[];         // al menos 1
}
