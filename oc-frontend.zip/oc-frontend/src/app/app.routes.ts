import { Routes } from '@angular/router';
import { OrdersListComponent } from './pages/orders-list/orders-list.component';
import { OrderFormComponent } from './pages/order-form/order-form.component';
import { OrderDetailComponent } from './pages/order-detail/order-detail.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'ordenes' },
  { path: 'ordenes', component: OrdersListComponent },
  { path: 'ordenes/nueva', component: OrderFormComponent },
  { path: 'ordenes/:id', component: OrderDetailComponent },
  { path: '**', redirectTo: 'ordenes' },
];
