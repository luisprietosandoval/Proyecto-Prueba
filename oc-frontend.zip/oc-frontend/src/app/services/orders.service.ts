import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Orden } from '../models/order';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class OrdersService {
  private base = `${environment.apiBase}/ordenes`;
  constructor(private http: HttpClient) {}

  listar(): Observable<Orden[]> { return this.http.get<Orden[]>(`${this.base}/ListaOrdenes`); }
  crear(o: Orden): Observable<Orden> { return this.http.post<Orden>(`${this.base}/CrearOrden`, o); }
  obtener(id: number): Observable<Orden> { return this.http.get<Orden>(`${this.base}/${id}`); }
}
