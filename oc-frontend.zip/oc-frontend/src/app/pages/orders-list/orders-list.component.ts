import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrdersService } from '../../services/orders.service';
import { Orden, Item } from '../../models/order';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-orders-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './orders-list.component.html'
})
export class OrdersListComponent implements OnInit {
  ordenes: Orden[] = [];
  loading = false;
  error?: string;

  constructor(private api: OrdersService, private router: Router) {}
  ngOnInit(): void { this.cargar(); }

  cargar() {
    this.loading = true;
    this.api.listar().subscribe({
      next: data => { this.ordenes = data; this.loading = false; },
      error: _ => { this.error = 'No se pudo cargar'; this.loading = false; }
    });
  }

  nueva() { this.router.navigate(['/ordenes/nueva']); }
  ver(o: Orden) { if (o.id) this.router.navigate(['/ordenes', o.id]); }
  
  getTotalItems(orden: Orden): number {
    return orden.items?.reduce((total: number, item: Item) => total + (item.cantidad || 0), 0) || 0;
  }
}
