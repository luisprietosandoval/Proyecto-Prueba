import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrdersService } from '../../services/orders.service';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './order-form.component.html'
})
export class OrderFormComponent {
  form!: FormGroup;

  get items() { return this.form.get('items') as FormArray; }

  constructor(private fb: FormBuilder, private api: OrdersService, private router: Router) {
    this.form = this.fb.group({
      cliente: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      fecha: ['', Validators.required],
      items: this.fb.array([
        this.fb.group({
          sku: ['', Validators.required],
          cantidad: [1, [Validators.required, Validators.min(1), Validators.max(100000)]]
        })
      ])
    });
  }

  addItem() {
    this.items.push(this.fb.group({
      sku: ['', Validators.required],
      cantidad: [1, [Validators.required, Validators.min(1), Validators.max(100000)]]
    }));
  }
  removeItem(i: number) { if (this.items.length > 1) this.items.removeAt(i); }

  submit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const payload = this.form.value as any; // fecha ya viene yyyy-MM-dd
    this.api.crear(payload).subscribe({
      next: _ => this.router.navigate(['/ordenes']),
      error: err => alert('Error creando: ' + (err?.error || err?.message || 'desconocido'))
    });
  }
}
