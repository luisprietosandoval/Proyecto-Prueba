import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OrdersService } from '../../services/orders.service';
import { Orden } from '../../models/order';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-detail.component.html'
})
export class OrderDetailComponent implements OnInit {
  orden?: Orden;
  loading = true; error?: string;

  constructor(private route: ActivatedRoute, private api: OrdersService) {}
  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.obtener(id).subscribe({
      next: o => { this.orden = o; this.loading = false; },
      error: _ => { this.error = 'No encontrada'; this.loading = false; }
    });
  }
}
