export const environment = {
  production: false,
  apiBase: 'http://localhost:56399'   // tu Web API .NET
};
