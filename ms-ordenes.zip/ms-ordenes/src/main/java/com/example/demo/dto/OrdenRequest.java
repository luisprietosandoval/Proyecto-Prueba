package com.example.demo.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.util.List;

public class OrdenRequest {
  @NotBlank
  private String cliente;

  @NotNull
  private LocalDate fecha; // formato ISO: "2025-08-12"

  @NotNull @Size(min = 1)
  private List<Item> items;

  public static class Item {
    @NotBlank
    private String sku;
    @NotNull
    private Integer cantidad;

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
  }

  public String getCliente() { return cliente; }
  public void setCliente(String cliente) { this.cliente = cliente; }
  public LocalDate getFecha() { return fecha; }
  public void setFecha(LocalDate fecha) { this.fecha = fecha; }
  public List<Item> getItems() { return items; }
  public void setItems(List<Item> items) { this.items = items; }
}