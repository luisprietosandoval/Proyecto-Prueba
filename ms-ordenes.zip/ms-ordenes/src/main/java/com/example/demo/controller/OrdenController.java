package com.example.demo.controller;


import com.example.demo.dto.OrdenRequest;
import com.example.demo.dto.OrdenResponse;
import com.example.demo.service.OrdenService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrdenController {

  private final OrdenService ordenService;

  public OrdenController(OrdenService ordenService) {
    this.ordenService = ordenService;
  }

  @PostMapping("/procesar-orden")
  public ResponseEntity<OrdenResponse> procesar(@Valid @RequestBody OrdenRequest request) throws Exception {
    int totalProductos = request.getItems().stream().mapToInt(i -> i.getCantidad()).sum();

    // Imprime en consola lo requerido
    System.out.println("Cliente: " + request.getCliente());
    System.out.println("Fecha: " + request.getFecha());
    System.out.println("Total de productos: " + totalProductos);

    // (Extra) Guardar log JSON
    ordenService.logProcesamiento(request, totalProductos);

    var resp = new OrdenResponse("OK", "Orden procesada correctamente", totalProductos);
    return ResponseEntity.ok(resp);
  }
}