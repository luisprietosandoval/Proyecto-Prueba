package com.example.demo.service;

import com.example.demo.dto.OrdenRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class OrdenService {

  private final ObjectWriter writer = new ObjectMapper().writerWithDefaultPrettyPrinter();

  public void logProcesamiento(OrdenRequest req, int total) throws Exception {
    var out = new java.util.LinkedHashMap<String, Object>();
    out.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
    out.put("cliente", req.getCliente());
    out.put("fecha", req.getFecha().toString());
    out.put("totalProductos", total);

    var dir = new File("logs");
    if (!dir.exists()) Files.createDirectories(dir.toPath());
    var file = new File(dir, "procesos.jsonl");
    Files.writeString(file.toPath(), writer.writeValueAsString(out) + System.lineSeparator(),
        java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
  }
}