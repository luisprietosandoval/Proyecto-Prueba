package com.example.demo.dto;

public class OrdenResponse {
	  private String estado;
	  private String mensaje;
	  private int totalProductos;

	  public OrdenResponse() {}
	  public OrdenResponse(String estado, String mensaje, int totalProductos) {
	    this.estado = estado; this.mensaje = mensaje; this.totalProductos = totalProductos;
	  }

	  public String getEstado() { return estado; }
	  public void setEstado(String estado) { this.estado = estado; }
	  public String getMensaje() { return mensaje; }
	  public void setMensaje(String mensaje) { this.mensaje = mensaje; }
	  public int getTotalProductos() { return totalProductos; }
	  public void setTotalProductos(int totalProductos) { this.totalProductos = totalProductos; }
	}
