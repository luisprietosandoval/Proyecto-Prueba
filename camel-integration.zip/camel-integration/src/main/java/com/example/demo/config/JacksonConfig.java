// src/main/java/com/example/demo/config/JacksonConfig.java
package com.example.demo.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {
	  @Bean
	  public ObjectMapper camelObjectMapper() {
	    var m = new ObjectMapper();
	    m.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
	    return m;
	  }
	}