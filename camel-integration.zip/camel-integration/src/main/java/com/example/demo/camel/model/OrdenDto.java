package com.example.demo.camel.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

public class OrdenDto {
  @NotBlank private String cliente;
  @JsonFormat(pattern = "yyyy-MM-dd")
  @NotNull private LocalDate fecha;
  @NotNull @Size(min = 1) private List<Item> items;

  public static class Item {
    @NotBlank private String sku;
    @NotNull private Integer cantidad;
    public String getSku() { return sku; } public void setSku(String sku) { this.sku = sku; }
    public Integer getCantidad() { return cantidad; } public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
  }

  public String getCliente() { return cliente; } public void setCliente(String cliente) { this.cliente = cliente; }
  public LocalDate getFecha() { return fecha; } public void setFecha(LocalDate fecha) { this.fecha = fecha; }
  public List<Item> getItems() { return items; } public void setItems(List<Item> items) { this.items = items; }
}