package com.example.demo.config;

import com.example.demo.camel.model.OrdenDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CamelDataFormats {

  @Bean
  public JacksonDataFormat ordenDtoJackson(ObjectMapper camelObjectMapper) {
    JacksonDataFormat df = new JacksonDataFormat(OrdenDto.class);
    df.setObjectMapper(camelObjectMapper); // <- usa nuestro mapper con JavaTimeModule
    return df;
  }
}
