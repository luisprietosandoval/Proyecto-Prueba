package com.example.demo.camel.routes;

import org.apache.camel.component.jackson.JacksonDataFormat;
import com.example.demo.camel.model.OrdenDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class OrdenFileToRestRoute extends RouteBuilder {

  // Valores por defecto para no fallar si falta la propiedad
  @Value("${inbox.dir:data/inbox}")
  String inboxDir;

  @Value("${log.dir:logs}")
  String logDir;

  @Value("${ms.url:http://localhost:8081/procesar-orden}")
  String microserviceUrl;
  
  @Autowired
  JacksonDataFormat ordenDtoJackson;

  @Override
  public void configure() {

    // === Manejo global de errores: mover a .error y dejar registro ===
    onException(Exception.class)
      .handled(true)
      .log("ERROR procesando ${header.CamelFileName}: ${exception.message}")
      .toD("file:" + inboxDir
          + "/.error?fileName=${file:name.noext}-${date:now:yyyyMMddHHmmss}.json");

    // === Ruta principal: carpeta -> validar -> POST -> log ===
    fromF("file:%s?include=.*\\.json&autoCreate=true&move=.done&moveFailed=.error", inboxDir)
    .routeId("file-to-rest-orden")
    .log("Leyendo ${file:name} desde ${file:absolute.path}")

    .convertBodyTo(String.class)
    .unmarshal(ordenDtoJackson)   // <- usa el dataformat con nuestro ObjectMapper
    .to("bean-validator://validarOrden")
    .marshal(ordenDtoJackson)     // <- vuelve a JSON con el mismo mapper

    .setHeader(Exchange.HTTP_METHOD, constant("POST"))
    .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
    .toD(microserviceUrl + "?connectTimeout=10000&responseTimeout=60000&throwExceptionOnFailure=false")
    // ... (processor y logging como ya tenías) ...

      // Registrar resultado en JSONL y fallar si httpCode >= 400
      .process(e -> {
        int code = e.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, 500, Integer.class);
        String resp = e.getMessage().getBody(String.class);

        // Log JSON line
        Map<String, Object> log = new LinkedHashMap<>();
        log.put("archivo", e.getMessage().getHeader(Exchange.FILE_NAME_ONLY, String.class));
        log.put("timestamp", OffsetDateTime.now().toString());
        log.put("httpCode", code);
        log.put("respuesta", resp);

        Path dir = Paths.get(logDir);
        if (!Files.exists(dir)) Files.createDirectories(dir);
        Path out = dir.resolve("camel-envios.jsonl");

        String line = new ObjectMapper()
            .writerWithDefaultPrettyPrinter()
            .writeValueAsString(log) + System.lineSeparator();

        Files.writeString(out, line,
            java.nio.file.StandardOpenOption.CREATE,
            java.nio.file.StandardOpenOption.APPEND);

        if (code >= 400) {
          throw new RuntimeException("Microservicio respondió " + code);
        }
      })

      .log("Archivo ${header.CamelFileName} enviado OK (HTTP ${header.CamelHttpResponseCode})");
  }
}
